/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Information;

/**
 *
 * @author WPF95
 */
public class Address {
  private String st_1;
  private String st_2;
  private String city;
  private String State;
  private int zip_code;
  private String country;

    public String getSt_1() {
        return st_1;
    }

    public void setSt_1(String st_1) {
        this.st_1 = st_1;
    }

    public String getSt_2() {
        return st_2;
    }

    public void setSt_2(String st_2) {
        this.st_2 = st_2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return State;
    }

    public void setState(String State) {
        this.State = State;
    }

    public int getZip_code() {
        return zip_code;
    }

    public void setZip_code(int zip_code) {
        this.zip_code = zip_code;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

  
  
    
}
