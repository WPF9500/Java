/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Information;

/**
 *
 * @author WPF95
 */
public class License_data {
    private String licensenum;
    private String license_iss;
    private String license_exp;
    private String license_type;
    private String license_holder;

    public String getLicensenum() {
        return licensenum;
    }

    public void setLicensenum(String licensenum) {
        this.licensenum = licensenum;
    }

    public String getLicense_iss() {
        return license_iss;
    }

    public void setLicense_iss(String license_iss) {
        this.license_iss = license_iss;
    }

    public String getLicense_exp() {
        return license_exp;
    }

    public void setLicense_exp(String license_exp) {
        this.license_exp = license_exp;
    }

    public String getLicense_type() {
        return license_type;
    }

    public void setLicense_type(String license_type) {
        this.license_type = license_type;
    }

    public String getLicense_holder() {
        return license_holder;
    }

    public void setLicense_holder(String license_holder) {
        this.license_holder = license_holder;
    }
    
    
}
