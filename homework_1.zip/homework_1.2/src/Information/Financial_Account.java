/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Information;

/**
 *
 * @author WPF95
 */
public class Financial_Account {
    private String Type;
    private int accnum;
    private String credate;/*creation date*/
    private String status;/*active or not*/
    private String accbank;/* which bank*/

    public String getType() {
        return Type;
    }

    public void setType(String Type) {
        this.Type = Type;
    }

    public int getAccnum() {
        return accnum;
    }

    public void setAccnum(int accnum) {
        this.accnum = accnum;
    }

    public String getCredate() {
        return credate;
    }

    public void setCredate(String credate) {
        this.credate = credate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAccbank() {
        return accbank;
    }

    public void setAccbank(String accbank) {
        this.accbank = accbank;
    }
    
}
