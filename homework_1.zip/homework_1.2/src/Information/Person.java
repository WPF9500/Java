/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Information;
import javax.swing.*;
/**
 *
 * @author WPF95
 */
public class Person {
private String lastName;
private String firstName;
private String dob;
private String sex;
private Address address;
private Credit_card credit;
private License_data license;
private Financial_Account account_1;
private Financial_Account account_2;
private JLabel picture;
private Integer telephone;
private Integer fax;
private String email;
private Integer ssn;

    public Integer getTelephone() {
        return telephone;
    }

    public void setTelephone(Integer telephone) {
        this.telephone = telephone;
    }

    public Integer getFax() {
        return fax;
    }

    public void setFax(Integer fax) {
        this.fax = fax;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getSsn() {
        return ssn;
    }

    public void setSsn(Integer ssn) {
        this.ssn = ssn;
    }



    public JLabel getPicture() {
        return picture;
    }

    public void setPicture(JLabel picture) {
        this.picture = picture;
    }



    public Financial_Account getAccount_1() {
        return account_1;
    }

    public void setAccount_1(Financial_Account account_1) {
        this.account_1 = account_1;
    }

    public Financial_Account getAccount_2() {
        return account_2;
    }

    public void setAccount_2(Financial_Account account_2) {
        this.account_2 = account_2;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public Credit_card getCredit() {
        return credit;
    }

    public void setCredit(Credit_card credit) {
        this.credit = credit;
    }

    public License_data getLicense() {
        return license;
    }

    public void setLicense(License_data license) {
        this.license = license;
    }

  

}
