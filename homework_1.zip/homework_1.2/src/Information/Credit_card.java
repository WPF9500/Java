/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Information;

/**
 *
 * @author WPF95
 */
public class Credit_card {
   private String credit_holder;
   private int credit_num;
   private int scode;
   private String exp;
   private String bank;

    public String getCredit_holder() {
        return credit_holder;
    }

    public void setCredit_holder(String credit_holder) {
        this.credit_holder = credit_holder;
    }

    public int getCredit_num() {
        return credit_num;
    }

    public void setCredit_num(int credit_num) {
        this.credit_num = credit_num;
    }

    public int getScode() {
        return scode;
    }

    public void setScode(int scode) {
        this.scode = scode;
    }

    public String getExp() {
        return exp;
    }

    public void setExp(String exp) {
        this.exp = exp;
    }

    public String getBank() {
        return bank;
    }

    public void setBank(String bank) {
        this.bank = bank;
    }
}
